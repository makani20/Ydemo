//
//  Restaurant.m
//  YelpNearby
//
//  Created by Behera, Subhransu on 8/14/13.
//  Copyright (c) 2013 Behera, Subhransu. All rights reserved.
//

#import "Restaurant.h"

@implementation Restaurant

@end
