//
//  OAuthAPIConstants.h
//  YelpNearby
//
//  Created by Behera, Subhransu on 8/14/13.
//  Copyright (c) 2013 Behera, Subhransu. All rights reserved.
//

#ifndef YelpNearby_OAuthAPIConstants_h
#define YelpNearby_OAuthAPIConstants_h

#define OAUTH_CONSUMER_KEY @"dvAmFjpVl0e0HY5rESQqNw"
#define OAUTH_CONSUMER_SECRET @"wejorcDc6GfGIiFJHwproMGacnQ"
#define OAUTH_TOKEN @"LL-lasxtUnNU6JMsToKI9mw0V6zcw7Br"
#define OAUTH_TOKEN_SECRET @"4kKh4vC32SgfpF0Qw5hZq9-rBmw"
#define YELP_SEARCH_URL @"http://api.yelp.com/v2/search"


#endif
